## 2. Why Learn the Command Line? ##

/home/dq$ date

## 3. The Prompt ##

/home/dq$ alsoNotRandom

## 4. The Anatomy of Commands ##

/home/dq$ diff augustus veruca

## 5. More on Commands ##

/home/dq$ diff -qy augustus tv

## 6. Command History ##

/home/dq$ history