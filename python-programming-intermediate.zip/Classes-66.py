## 2. Defining the Dataset Class ##

class Dataset:
    def __init__(self):
        self.type = "csv"
        
dataset = Dataset()
print(dataset.type)

## 3. Passing Additional Arguments to the Initializer ##

import csv

# Default display code
class Dataset:
    def __init__(self, data):
        self.type = "csv"
        self.data = data
        
f = open("nfl.csv", "r")
nfl_data = list(csv.reader(f))
nfl_dataset = Dataset(nfl_data)
dataset_data = nfl_dataset.data 
print(dataset_data)
        

## 4. Adding Additional Behavior ##

# Default display code
class Dataset:
    def __init__(self, data):
        self.data = data
        
    # Your method goes here
    def print_data(self, num_rows):
        print(self.data[:num_rows])
        
nfl_dataset = Dataset(nfl_data)
nfl_dataset.print_data(5)

## 5. Enhancing the Initializer ##

# Default display code
class Dataset:
    def __init__(self, data):
        self.data = data[1:]
        self.header = data[0]

nfl_dataset = Dataset(nfl_data)
nfl_header = nfl_dataset.header

## 6. Grabbing Column Data ##

# Default display code
class Dataset:
    def __init__(self, data):
        self.header = data[0]
        self.data = data[1:]
        
    # Add your method here.
    def column(self, label):
        
        if label not in self.header:
            return None
        
        index = 0
        for idx, value in enumerate(self.header):
            if value == label:
                index = idx
               
        column_data = []    
        for row in self.data:
            column_data.append(row[index])
            
        return column_data
           
nfl_dataset = Dataset(nfl_data)
year_column = nfl_dataset.column('year')
player_column = nfl_dataset.column('player')

## 7. Count Unique Method ##

# Default display code
class Dataset:
    def __init__(self, data):
        self.header = data[0]
        self.data = data[1:]
    
    def column(self, label):
        """returns content of column
           based on label"""
        if label not in self.header:
            return None
        
        index = 0
        for idx, element in enumerate(self.header):
            if label == element:
                index = idx
        
        column = []
        for row in self.data:
            column.append(row[index])
        return column
    
    # Add your count unique method here
    def count_unique(self, label):
        total_count = len(set(self.column(label)))
        return total_count

nfl_dataset = Dataset(nfl_data)
total_years = nfl_dataset.count_unique('year')

## 8. Make Objects Human Readable ##

['# Default display code\nclass Dataset:\n    def __init__(self, data):\n        self.header = data[0]\n        self.data = data[1:]\n    \n    def __str__(self):\n        data_string = self.data[:10]\n        return str(data_string)\n    \n    def column(self, label):\n        if label not in self.header:\n            return None\n        \n        index = 0\n        for idx, element in enumerate(self.header):\n            if label == element:\n                index = idx\n        \n        column = []\n        for row in self.data:\n            column.append(row[index])\n        return column\n    \n        \n    def count_unique(self, label):\n        unique_results = set(self.column(label))\n        count = len(unique_results)\n        return count\n\nnfl_dataset = Dataset(nfl_data)\nprint(nfl_dataset)']