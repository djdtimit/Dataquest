## 2. Running a Python Script to Explore the Columns ##

/home/dq/scripts$ ls

## 6. Next Steps ##

/home/dq/scripts$ ls